from setuptools import setup

setup(name='BinoGauss_Probability',
      version='1.2',
      description='Gaussian distributions',
      packages=['BinoGauss_Probability'],
      zip_safe=False)
